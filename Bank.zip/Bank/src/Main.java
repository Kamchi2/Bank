import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws LimitException {
        Scanner scan = new Scanner(System.in);
        BankAccount client = new BankAccount(20000);
        while (true) {
            System.out.println("Денег: " + client.amount);
            System.out.println("Выберите действие:" + "\n1) Выход" + "\n2) Положить деньгн на счет" + "\n3) Снять деньги с счета");
            int vibor = scan.nextInt();
            if (vibor == 1) {
                break;
            } else if (vibor == 2) {
                System.out.print("Сумма: ");
                double sum = scan.nextDouble();
                client.deposit(sum);
            } else if (vibor == 3) {
                System.out.print("Сумма: ");
                int sum = scan.nextInt();
                client.withDraw(sum);
            }
        }
    }
}
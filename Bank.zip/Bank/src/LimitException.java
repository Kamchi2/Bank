public class LimitException extends Exception {
    public LimitException(String message, double remainingAmount) {
        super(message + remainingAmount);
    }

    public static double getRemainingAmount(int sum, double amount) {
        return sum - amount;
    }
}


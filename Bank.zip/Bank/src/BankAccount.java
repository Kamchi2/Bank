public class BankAccount {
    double amount;

    public BankAccount(double amount) {
        this.amount = amount;
    }

    public double getAmount() {
        return amount;
    }

    public void deposit(double sum){
        this.amount += sum;
    }
    public void withDraw(int sum) throws LimitException {
        if (sum <= this.amount){
            this.amount -= sum;
        } else{
            try {
                throw new LimitException("Недостаточно средств", this.amount);
            } catch (LimitException e) {
                System.out.println("Недостаточно средств: " + LimitException.getRemainingAmount(sum, amount));
            }
        }
    }
}